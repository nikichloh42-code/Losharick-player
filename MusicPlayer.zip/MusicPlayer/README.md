# My Player — музыкальный плеер для Android

Офлайн-плеер: сам находит музыку на телефоне, работает без интернета.

## Как собрать APK через GitHub
1. Создай на github.com новый репозиторий (New repository), например `my-player`.
2. Загрузи в него ВСЕ файлы из этой папки (Add file → Upload files), включая скрытую папку `.github`.
   Проще через git: `git init && git add . && git commit -m init && git branch -M main && git remote add origin <ссылка> && git push -u origin main`
3. Открой вкладку **Actions** → **Build APK** → дождись зелёной галочки (5–10 минут).
4. Внутри запуска внизу в разделе **Artifacts** скачай `MusicPlayer-apk` (zip), распакуй — там `MusicPlayer.apk`.
5. Кинь APK на телефон, открой, разреши «установку из неизвестных источников».

### Ссылка для друзей
Создай тег: Releases → Draft a new release → тег `v1.0` → Publish.
Actions сам прикрепит `MusicPlayer.apk` к релизу — ссылку на релиз можно кидать друзьям.

## Структура
- `app/src/main/java/com/example/musicplayer/` — весь код (Kotlin + Jetpack Compose + Media3)
- `.github/workflows/build.yml` — автосборка APK
