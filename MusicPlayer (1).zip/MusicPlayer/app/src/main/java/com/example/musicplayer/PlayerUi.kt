package com.example.musicplayer

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import kotlinx.coroutines.launch

private fun modeIcon(m: Int) = when (m) {
    1 -> Icons.Filled.Shuffle
    2 -> Icons.Filled.RepeatOne
    else -> Icons.Filled.FormatListNumbered
}

private fun modeName(m: Int) = when (m) {
    1 -> tr("Shuffle", "Aleatorio", "Вперемешку")
    2 -> tr("Repeat one", "Repetir una", "Повтор одной")
    else -> tr("In order", "En orden", "По очереди")
}

// ---------------------------------------------------------------- мини-плеер

@Composable
fun MiniPlayer(h: PlayerHolder, s: Song?, onOpen: () -> Unit) {
    if (s == null) return
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = if (Store.wallOn) 0.85f else 1f),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen)
    ) {
        Column {
            LinearProgressIndicator(
                progress = { if (h.duration > 0) (h.position.toFloat() / h.duration).coerceIn(0f, 1f) else 0f },
                modifier = Modifier.fillMaxWidth().height(2.dp)
            )
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(s, Modifier.size(44.dp), 128, 6.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text(
                        s.who, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                IconButton(onClick = { h.toggle() }) {
                    Icon(if (h.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null)
                }
                IconButton(onClick = { h.next() }) { Icon(Icons.Filled.SkipNext, null) }
            }
        }
    }
}

// ---------------------------------------------------------------- полноэкранный плеер

@Composable
fun FullPlayer(h: PlayerHolder, s: Song?, act: Actions, onClose: () -> Unit, onQueue: () -> Unit) {
    Screen {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 10.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Filled.KeyboardArrowDown, null) }
                Text(
                    tr("Now playing", "Reproduciendo", "Сейчас играет"),
                    Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleMedium
                )
                IconButton(onClick = onQueue) { Icon(Icons.AutoMirrored.Filled.QueueMusic, null) }
            }

            // обложка: почти на всю ширину экрана, скругление совсем небольшое
            Cover(s, Modifier.fillMaxWidth().aspectRatio(1f), 1024, 12.dp)

            Spacer(Modifier.height(16.dp))
            Row(Modifier.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        s?.name ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold
                    )
                    Text(
                        s?.who ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                }
                if (s != null) {
                    val liked = s.id in Store.likes
                    IconButton(onClick = { Store.toggleLike(s.id) }) {
                        Icon(
                            if (liked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null,
                            tint = if (liked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground
                        )
                    }
                    IconButton(onClick = { act.edit(s) }) { Icon(Icons.Filled.Edit, null) }
                }
            }

            var drag by remember { mutableStateOf<Float?>(null) }
            val dur = if (h.duration > 0) h.duration else (s?.duration ?: 0L)
            val frac = if (dur > 0) (h.position.toFloat() / dur).coerceIn(0f, 1f) else 0f
            Slider(
                value = drag ?: frac,
                onValueChange = { drag = it },
                onValueChangeFinished = {
                    drag?.let { h.seek((it * dur).toLong()) }
                    drag = null
                }
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
                Text(fmtTime(((drag ?: frac) * dur).toLong()), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                Text(fmtTime(dur), style = MaterialTheme.typography.bodySmall)
            }

            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { h.setMode((h.mode() + 1) % 3) }) {
                    Icon(modeIcon(h.mode()), modeName(h.mode()), tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { h.prev() }, Modifier.size(56.dp)) {
                    Icon(Icons.Filled.SkipPrevious, null, Modifier.size(36.dp))
                }
                FilledIconButton(onClick = { h.toggle() }, Modifier.size(72.dp)) {
                    Icon(if (h.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(40.dp))
                }
                IconButton(onClick = { h.next() }, Modifier.size(56.dp)) {
                    Icon(Icons.Filled.SkipNext, null, Modifier.size(36.dp))
                }
                IconButton(onClick = onQueue) { Icon(Icons.AutoMirrored.Filled.QueueMusic, null) }
            }
            Text(
                modeName(h.mode()), Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp),
                textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

// ---------------------------------------------------------------- очередь (как в LarkPlayer)

@Composable
fun QueueScreen(h: PlayerHolder, byId: Map<Long, Song>, onBack: () -> Unit) {
    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val local = remember { mutableStateListOf<Long>() }     // локальная копия очереди на время перетаскивания
    var dragIndex by remember { mutableIntStateOf(-1) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    var first by remember { mutableStateOf(true) }

    LaunchedEffect(h.queue, dragIndex) {
        if (dragIndex == -1) {
            local.clear()
            local.addAll(h.queue)
            if (first && local.isNotEmpty()) {
                first = false
                withFrameNanos { }
                state.scrollToItem((h.index - 1).coerceAtLeast(0))
            }
        }
    }

    val bg = lerp(Color.Black, MaterialTheme.colorScheme.primary, 0.55f)
    val song = byId[h.currentId]

    Box(Modifier.fillMaxSize().background(bg).systemBarsPadding()) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            Column(Modifier.fillMaxSize()) {
                // ---- верхняя полоска: что играет сейчас
                Row(Modifier.padding(start = 16.dp, end = 12.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Cover(song, Modifier.size(60.dp), 200, 12.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Text(song?.name ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 20.sp)
                        Text(
                            song?.who ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontSize = 15.sp, color = Color.White.copy(alpha = 0.7f)
                        )
                        LinearProgressIndicator(
                            progress = { if (h.duration > 0) (h.position.toFloat() / h.duration).coerceIn(0f, 1f) else 0f },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                            color = Color.White.copy(alpha = 0.8f),
                            trackColor = Color.White.copy(alpha = 0.2f)
                        )
                    }
                    IconButton(onClick = { h.toggle() }, Modifier.size(48.dp)) {
                        Icon(if (h.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null, Modifier.size(36.dp))
                    }
                }

                // ---- «шторка» со списком
                Column(
                    Modifier.weight(1f).fillMaxWidth()
                        .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                        .background(Color.White.copy(alpha = 0.06f))
                ) {
                    IconButton(onClick = onBack, Modifier.align(Alignment.CenterHorizontally)) {
                        Icon(Icons.Filled.KeyboardArrowDown, null, Modifier.size(32.dp))
                    }
                    Row(Modifier.padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            tr("Queue", "Cola", "Очередь"), Modifier.weight(1f),
                            fontSize = 32.sp, fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = {
                            scope.launch { state.animateScrollToItem((h.index - 1).coerceAtLeast(0)) }
                        }) { Icon(Icons.Filled.CenterFocusStrong, null) }
                        IconButton(onClick = { h.clear() }) { Icon(Icons.Filled.CleaningServices, null) }
                    }
                    Spacer(Modifier.height(8.dp))

                    LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = state) {
                        items(local.size) { i ->
                            val s = byId[local[i]]
                            if (s != null) {
                                val cur = local[i] == h.currentId
                                val dragging = i == dragIndex
                                Box(Modifier.fillMaxWidth().zIndex(if (dragging) 1f else 0f)) {
                                    Row(
                                        Modifier.fillMaxWidth()
                                            .graphicsLayer { translationY = if (dragging) dragOffset else 0f }
                                            .background(if (dragging) bg else Color.Transparent)
                                            .clickable { h.jump(i) }
                                            .padding(horizontal = 16.dp, vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(Modifier.size(60.dp), contentAlignment = Alignment.Center) {
                                            Cover(s, Modifier.fillMaxSize(), 200, 12.dp)
                                            if (cur) {
                                                Box(
                                                    Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                                                        .background(Color.Black.copy(alpha = 0.5f)),
                                                    contentAlignment = Alignment.Center
                                                ) { Icon(Icons.Filled.GraphicEq, null, Modifier.size(34.dp)) }
                                            }
                                        }
                                        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                                            Text(s.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 18.sp)
                                            Text(
                                                s.who + " - " + s.album, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                                fontSize = 14.sp, color = Color.White.copy(alpha = 0.7f)
                                            )
                                        }
                                        Icon(Icons.Filled.Menu, null, Modifier.size(32.dp).padding(end = 4.dp))
                                    }
                                    // невидимая зона-ручка справа: за неё тянем песню вверх/вниз
                                    Box(
                                        Modifier.align(Alignment.CenterEnd).size(width = 72.dp, height = 76.dp)
                                            .pointerInput(Unit) {
                                                detectDragGestures(
                                                    onDragStart = { dragIndex = i; dragOffset = 0f },
                                                    onDragEnd = { dragIndex = -1; dragOffset = 0f },
                                                    onDragCancel = { dragIndex = -1; dragOffset = 0f },
                                                    onDrag = { change, amount ->
                                                        change.consume()
                                                        dragOffset += amount.y
                                                        val size = state.layoutInfo.visibleItemsInfo
                                                            .firstOrNull { it.index == dragIndex }?.size?.toFloat() ?: 1f
                                                        if (dragOffset > size / 2 && dragIndex in 0 until local.lastIndex) {
                                                            local.add(dragIndex + 1, local.removeAt(dragIndex))
                                                            h.move(dragIndex, dragIndex + 1)
                                                            dragIndex += 1
                                                            dragOffset -= size
                                                        } else if (dragOffset < -size / 2 && dragIndex > 0) {
                                                            local.add(dragIndex - 1, local.removeAt(dragIndex))
                                                            h.move(dragIndex, dragIndex - 1)
                                                            dragIndex -= 1
                                                            dragOffset += size
                                                        }
                                                    }
                                                )
                                            }
                                    )
                                }
                            }
                        }
                    }

                    // ---- режимы: повтор одной / по очереди / вперемешку
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        listOf(2 to Icons.Filled.RepeatOne, 0 to Icons.Filled.Repeat, 1 to Icons.Filled.Shuffle)
                            .forEach { (m, ic) ->
                                val sel = h.mode() == m
                                Box(
                                    Modifier.weight(1f).height(64.dp)
                                        .clip(RoundedCornerShape(32.dp))
                                        .background(if (sel) Color.White else Color.White.copy(alpha = 0.12f))
                                        .clickable { h.setMode(m) },
                                    contentAlignment = Alignment.Center
                                ) { Icon(ic, modeName(m), tint = if (sel) bg else Color.White) }
                            }
                    }
                }
            }
        }
    }
}
